require('dotenv').config()
const express = require('express')
const mongoose = require('mongoose')
const session = require('express-session')
const app = express()

mongoose.set('strictQuery', true)
app.use(
  session({
    secret:"my secret",
    saveUninitialized: true,
    resave: false,
  })
)


//Set template engine
app.set("view engine", "ejs")

//route prefix
app.use("", require("./routes/route"))

app.use((req, res, next) => {
  res.locals.message = req.session.message;
  delete req.session.message;
  next();
})

app.use(express.static('uploads'))

app.use(express.urlencoded({extended: true}))
app.use(express.json())


app.listen(3300, console.log('serevr is running on port 3300'))

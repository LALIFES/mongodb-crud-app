const mongoose = require("mongoose")

const mongoDB = "mongodb+srv://mongodb:azerty0101@cluster0.tx6zd6w.mongodb.net/?retryWrites=true&w=majority"
mongoose.connect(mongoDB).then(() => console.log("Connection succes..."))
.catch(() =>console.log("CConnection failed"))
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    image: {
        type: String,
        required: true
    },
    created: {
        type: Date,
        required: true,
        default: Date.now
    }
})

module.exports = mongoose.model('user', userSchema)

